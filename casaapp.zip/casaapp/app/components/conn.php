
<?php
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "casadb";
 
 // Create connection
 $conn = new mysqli($servername, $username, $password, $dbname);
 // Check connection
 if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
 }
 //get the post records
 $name =$_POST['name'];
 $companyname =$_POST['companyname'];
 $roleincompany =$_POST['roleincompany'];
 $email =$_POST['email'];
 $telphno =$_POST['telphno'];

 //insert values
 $sql="INSERT INTO data(name,companyname,roleincompany,email,telphno)
   VALUES('$name','$companyname','$roleincompany','$email','$telphno')";

//update values

if ($conn->query($sql) === TRUE) {
   echo "New record created successfully";
 } else {
   echo "Error: " . $sql . "<br>" . $conn->error;
 }
 
 $conn->close();    
   
?>
 

