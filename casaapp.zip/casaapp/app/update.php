<?php 
include "config.php";

// if the form's update button is clicked, we need to process the form
	if (isset($_POST['update'])) {
	    $id=$_POST['id'];
		$name = $_POST['name'];
		$companyname = $_POST['companyname'];
		$roleincompany = $_POST['roleincompany'];
		$email = $_POST['email'];
		$telphno = $_POST['telphno'];
		
		
		// write the update query
		$sql = " UPDATE data SET name='".$name."',companyname='".$companyname."',roleincompany='".$roleincompany."',
		 email='".$email."',telphno='".$telphno."'WHERE id='".$id."'";
	
		// execute the query
		$result = $conn->query($sql);
		// echo($sql);
		// die();
		if ($result == TRUE) {
			echo "Record updated successfully.";
		}else{
			echo "Error:" . $sql . "<br>" . $conn->error;
		}
	}


// if the 'id' variable is set in the URL, we know that we need to edit a record
if (isset($_GET['id'])) {
	$id = $_GET['id'];

	// write SQL to get user data
	$sql = "SELECT * FROM `data` WHERE `id`='$id'";

	//Execute the sql
	$result = $conn->query($sql); 

	if ($result->num_rows > 0) {
		
		while ($row = $result->fetch_assoc()) {
			$id = $row['id'];
			$name = $row['name'];
			$companyname = $row['companyname'];
			$roleincompany  = $row['roleincompany'];
			$email = $row['email'];
			$telphno = $row['telphno'];
			
		}

	?>
	
		<h2>User Update Form</h2>
		<form action="" method="post">
		  <fieldset>
		    <legend>userinformation:</legend>
		     name:<br>
		    <input type="text" name="name" value="<?php echo $name; ?>">
		    <input type="hidden" name="id" value="<?php echo $id; ?>">
		    <br>
		     companyname:<br>
		    <input type="text" name="companyname" value="<?php echo $companyname; ?>">
		    <br>
		     roleincompany:<br>
		    <input type="text" name="roleincompany" value="<?php echo $roleincompany; ?>">
		    <br>
		    email:<br>
		    <input type="text" name="email" value="<?php echo $email; ?>">
		     <br>
		    telphno:<br>
		    <input type="text" name="telphno" value="<?php echo $telphno; ?>">
		    <br><br>
			 <button type="update" class="btn btn-primary" name="update">update</button> 
		    
		  </fieldset>
		</form>

		</body>
		</html>
		
	<?php
	} else{
		// If the 'id' value is not valid, redirect the user back to page
		header('Location: view.php');
	}

}
?>